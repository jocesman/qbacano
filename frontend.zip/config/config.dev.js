export const CONFIG = {
  api: {
    baseUrl: 'http://localhost:3001/api'
  },

  whatsapp: {
    businessPhone: '529812100778'
  },

  session: {
    duration: 10 * 60 * 1000,
    warningTime: 2 * 60 * 1000
  },

  images: {
    fallback: 'img/logo.png'
  }
};